//
//  GamesViewController.h
//  iPoochie
//
//  Created by marta wilgan on 4/17/13.
//  Copyright (c) 2013 NYU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GamesViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *pointsLabel;
@property (strong, nonatomic) NSNumber *points;

- (IBAction)matchingGame:(UIButton *)sender;
- (IBAction)chanceGame:(UIButton *)sender;

@end
