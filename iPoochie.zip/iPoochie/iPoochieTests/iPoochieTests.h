//
//  iPoochieTests.h
//  iPoochieTests
//
//  Created by marta wilgan on 4/17/13.
//  Copyright (c) 2013 NYU. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface iPoochieTests : SenTestCase

@end
